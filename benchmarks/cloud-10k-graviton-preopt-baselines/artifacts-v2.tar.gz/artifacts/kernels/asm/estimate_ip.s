None refers to multiple packages, you need to specify which one to use
	-p ecaz
	-p ecaz-cli
	-p ecaz-cloud
Error: Multiple packages found
